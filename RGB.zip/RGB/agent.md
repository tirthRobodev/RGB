# CellCare Light Therapy System - Project Handoff

This document provides a complete technical overview of the "CellCare Light Therapy System" project (RGB Chamber). It is designed to help any AI assistant quickly understand the architecture, codebase, and state of the project.

## 1. Project Overview
The project is a smart Light Therapy Chamber that controls top and bottom RGB LED arrays (NeoPixels) via an ESP32-C3 microcontroller. A web-based dashboard (built with Flask) allows users to configure the active tray, wavelength (color), and duration, and to start/stop therapy sessions. State synchronization between the dashboard and the ESP32 hardware is handled entirely via Firebase Realtime Database.

## 2. System Architecture
- **Hardware**: ESP32-C3 running Arduino C++.
- **Hardware Peripherals**: Two Adafruit NeoPixel strips (`LED_PIN_TOP=1`, `LED_PIN_BOTTOM=0`), 84 LEDs each.
- **Backend**: Python Flask server (`dashboard/app.py`). Uses the `requests` library to communicate via Firebase's REST API.
- **Frontend**: Vanilla HTML/CSS/JS (`dashboard/templates/index.html`, `dashboard/static/style.css`).
- **Database**: Firebase Realtime Database (URL: `https://rgb-chamber-default-rtdb.firebaseio.com`).

## 3. Firebase Schema
The ESP32 and Flask dashboard communicate using the following JSON schema at the root node `/rgb_chamber`:

```json
{
  "rgb_chamber": {
    "config": {
      "tray": "top",          // "top", "bottom", or "both"
      "wavelength": 450,      // Integer (380 - 700)
      "minutes": 10,          // Integer
      "seconds": 0            // Integer
    },
    "command": {
      "action": "start",      // "start", "stop", or "pause"
      "requestId": 3          // Integer (incremented by dashboard to trigger ESP32 action)
    },
    "status": {
      "running": false,       // Boolean indicating if therapy is active
      "state": "CONFIGURED",  // "IDLE", "CONFIGURED", "RUNNING", "PAUSED", "COMPLETED"
      "tray": "top",
      "wavelength": 450,
      "minutes": 10,
      "seconds": 0,
      "remaining": 600000,    // Remaining time in milliseconds
      "lastUpdated": 462310   // ESP32 uptime in ms (heartbeat)
    }
  }
}
```

## 4. Codebase Structure & Logic

### ESP32 Firmware (`RGB_CHAMBER/RGB_CHAMBER.ino`)
- **WiFi Initialization**: Configured specifically for ESP32-C3 (Tx Power set to 8.5 dBm to prevent RF brownouts, connection polling loop).
- **Session Management**: Uses `millis()` for non-blocking timers. Maintains a `SystemState` enum.
- **Firebase Sync**: Polls `config.json` and `command.json` via HTTPS GET requests using `WiFiClientSecure` (with `setInsecure()` to bypass cert validation). Pushes status to `status.json` via PUT requests.
- **Hardware Output**: Converts the selected wavelength (nm) into an RGB color and fills the NeoPixel strips.

### Flask Backend (`dashboard/app.py`)
- Acts as a proxy to Firebase to prevent exposing credentials to the frontend and to handle logic like `requestId` incrementing.
- **Endpoints**:
  - `GET /` -> Renders `index.html`
  - `POST /api/config` -> PUTs tray, wavelength, minutes, and seconds to `/rgb_chamber/config.json`.
  - `POST /api/command` -> Fetches the current `requestId`, increments it by 1, and PUTs the new `action` and `requestId` to `/rgb_chamber/command.json`.
  - `GET /api/status` -> Fetches and returns the latest data from `/rgb_chamber/status.json`.

### Frontend (`dashboard/templates/index.html` & `dashboard/static/style.css`)
- **Design**: "CellCare Light Therapy System" UI. Mobile-first, centered layout. Features glassmorphism, dark blue gradients (`#071533`), and a modern aesthetic using the 'Inter' font.
- **Components**: 
  - Tray Selection Cards (Top / Bottom) with CSS-rendered LED ring mocks.
  - Custom Wavelength Range Slider (380-700nm) with a multi-colored spectrum track and an interactive tooltip indicating the specific color.
  - Duration input fields.
  - Large blue Start/Stop Therapy button.
- **JS Logic**: 
  - `updateSliderUI()`: Maps nanometers to color names.
  - `pushConfig()`: Sends config via `fetch('/api/config')` whenever an input changes.
  - `toggleTherapy()`: Sends "start" or "stop" to `/api/command`.
  - `pollStatus()`: Runs every 1 second (`setInterval`), fetches `/api/status`, and updates the UI (time remaining, button state, disables inputs when running).

## 5. Recent Fixes & Modifications
1. **ESP32 WiFi Stability**: Modified `RGB_CHAMBER.ino` to include a 2s boot delay for USB CDC, lowered Tx power to 8.5dBm, and implemented a non-blocking `WiFi.reconnect()` loop checking the connection every 5 seconds.
2. **Dashboard Complete Overhaul**: Completely rewrote the dashboard (both Python backend and HTML/CSS/JS frontend) to fully match the requested "CellCare" UI and hook up directly to the Firebase architecture.
