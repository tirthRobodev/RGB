from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)

FIREBASE_URL = "https://rgb-chamber-default-rtdb.firebaseio.com"
FIREBASE_TIMEOUT = 5  # seconds

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/config', methods=['POST'])
def update_config():
    data = request.json
    # data expects: tray, wavelength, minutes, seconds
    url = f"{FIREBASE_URL}/rgb_chamber/config.json"
    try:
        response = requests.put(url, json=data, timeout=FIREBASE_TIMEOUT)
        if response.status_code == 200:
            return jsonify({"status": "success", "data": response.json()})
        return jsonify({"status": "error", "message": f"Firebase returned {response.status_code}"}), 502
    except requests.exceptions.RequestException as e:
        return jsonify({"status": "error", "message": str(e)}), 503

@app.route('/api/command', methods=['POST'])
def send_command():
    data = request.json
    action = data.get("action", "start")

    # First, get current command to increment requestId
    get_url = f"{FIREBASE_URL}/rgb_chamber/command.json"
    try:
        current_cmd = requests.get(get_url, timeout=FIREBASE_TIMEOUT).json() or {}
        req_id = current_cmd.get("requestId", 0) + 1

        payload = {
            "action": action,
            "requestId": req_id
        }

        response = requests.put(get_url, json=payload, timeout=FIREBASE_TIMEOUT)
        if response.status_code == 200:
            return jsonify({"status": "success", "requestId": req_id})
        return jsonify({"status": "error", "message": f"Firebase returned {response.status_code}"}), 502
    except requests.exceptions.RequestException as e:
        return jsonify({"status": "error", "message": str(e)}), 503

@app.route('/api/status', methods=['GET'])
def get_status():
    url = f"{FIREBASE_URL}/rgb_chamber/status.json"
    try:
        response = requests.get(url, timeout=FIREBASE_TIMEOUT)
        if response.status_code == 200:
            return jsonify(response.json())
        return jsonify({"status": "error", "message": f"Firebase returned {response.status_code}"}), 502
    except requests.exceptions.RequestException as e:
        return jsonify({"status": "error", "message": str(e)}), 503

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)
