# RGB CHAMBER - Documentation & Setup

## 1. Setup Instructions

### Firebase Setup
1. Go to the Firebase Console: https://console.firebase.google.com/
2. Ensure you have your project `rgb-chamber` active.
3. In **Realtime Database**, check your rules. They are currently set to open mode (expires on 2026-10-22).
4. *(Optional but Recommended)*: Go to **Authentication**, click **Get Started**, and enable **Anonymous** sign-in provider. Then update your Realtime Database rules to `auth != null` for production.

### Firmware Setup (ESP32-C3)
1. Open `RGB_CHAMBER/RGB_CHAMBER.ino` in the Arduino IDE.
2. Install Required Libraries via Library Manager:
   - `ArduinoJson` (by Benoit Blanchon)
   - `Adafruit NeoPixel` (by Adafruit)
3. Board Setup:
   - Select **ESP32C3 Dev Module** (or your specific mini board).
   - Ensure you select the correct COM port.
4. Update WiFi Credentials at the top of the file:
   ```cpp
   const char* ssid = "RGB_WIFI";
   const char* password = "rgb!@123";
   ```
5. Click **Upload**.

### Dashboard Setup
1. The dashboard is entirely client-side.
2. You can simply open `dashboard/index.html` in any web browser, or host it on **Firebase Hosting** or **GitHub Pages**.
3. It will immediately connect to your Firebase project using the provided config.

---

## 2. Testing Checklist

- [ ] **Normal Operation**: Open the dashboard, set wavelength to 500, time to 5 minutes, and click Start. The dashboard timer should count down, and the ESP32 LEDs should turn green.
- [ ] **Mid-Session Wi-Fi Drop**: While running, unplug your home router. The dashboard will show "Offline". The ESP32 should **continue** to count down internally and keep the lights on.
- [ ] **Reconnection**: Plug the router back in. The dashboard should eventually flip back to "Online", and the timer should sync up perfectly with the ESP32's internal countdown.
- [ ] **Session Reaching Zero**: Wait for the timer to reach 00:00. The ESP32 should turn off the LEDs, and the dashboard should automatically switch to `COMPLETED` state.
- [ ] **Multiple Tabs**: Open the dashboard in two different browser tabs. Click Pause on one. The other tab should immediately reflect the paused state.

---

## 3. Architecture Decisions

### REST API vs. Library for ESP32
We chose the **REST API (`HTTPClient`)** over a heavy library like `Firebase ESP Client`.
**Why?**
1. **Memory & Stability**: The ESP32-C3 has limited resources. The REST API is extremely predictable, doesn't leak memory over long periods, and uses the built-in HTTP stack.
2. **Control over Polling**: We use a `WiFiClientSecure` object that is reused across requests. This avoids the costly 1.5-second TLS handshake on every poll.
3. **Interval**: The polling interval is set to **1.5 seconds**. This is frequent enough that the dashboard feels responsive (clicks register quickly), but slow enough that we don't spam Firebase API quotas or block the ESP32's `loop()` from running the LED animations smoothly.

### State Truth
The Firebase database acts as a messaging bus. The ESP32 is the **authoritative timer**. It doesn't rely on Firebase timestamps. It reads the config once, calculates a duration, and counts down using its own hardware `millis()`. This guarantees the lights turn off exactly when they should, even if the internet goes down.
